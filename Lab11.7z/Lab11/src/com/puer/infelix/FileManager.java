package com.puer.infelix;

import javax.swing.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileManager {
    private String fileName;
    private JPanel panel;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) throws IllegalDotException {
        if (fileName.contains(".")) {
            throw new IllegalDotException("There is a dot in the name of the file!");
        } else {
            this.fileName = fileName;
        }
    }

    FileManager(String fileName, JPanel panel) throws IllegalDotException {
        try {
            this.panel = panel;
            if (fileName.contains(".")) {
                throw new IllegalDotException("There is a dot in the name of the file!");
            } else {
                this.fileName = fileName;
            }
        }
        catch (IllegalDotException ex) {
            JOptionPane.showMessageDialog(panel, "Error was occurred: " +ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void createFile() throws IOException {
        File file = new File(fileName +".txt");
    }
}
