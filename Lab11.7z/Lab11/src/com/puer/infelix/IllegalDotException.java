package com.puer.infelix;

public class IllegalDotException extends Exception{
     public IllegalDotException(String message) {
         super(message);
     }
}
